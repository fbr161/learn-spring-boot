package com.example.learnspringaopsec17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringAopSec17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
