package com.example.learnaop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
